#include <stdlib.h>
int main(int argc, char **argv) {
  qsort_r(0, 0, 0, 0, 0);
  return 0;
}
