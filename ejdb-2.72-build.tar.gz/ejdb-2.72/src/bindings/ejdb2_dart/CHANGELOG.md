ejdb_dart (@EJDB2_DART_VERSION@)

- Upgraded to ejdb2 v@PROJECT_VERSION@