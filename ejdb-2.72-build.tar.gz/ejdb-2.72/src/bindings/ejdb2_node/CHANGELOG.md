ejdb_node (@EJDB2_NODE_VERSION@)

- Upgraded to ejdb2 v@PROJECT_VERSION@
