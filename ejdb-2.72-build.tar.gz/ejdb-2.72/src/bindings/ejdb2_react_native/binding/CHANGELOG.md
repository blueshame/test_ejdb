ejdb2_react_native (@EJDB2_RN_VERSION@)

- Upgraded to ejdb2 v@PROJECT_VERSION@
