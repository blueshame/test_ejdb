## @EJDB2_FLUTTER_VERSION@

- Fixed java.util.concurrent.RejectedExecutionException #305 
- Upgraded to ejdb2 v@PROJECT_VERSION@

