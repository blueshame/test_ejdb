/// Sample records put/query example
#include <ejdb2.h>
#include <string.h>

#define CHECK(rc_)          \
  if (rc_) {                 \
    iwlog_ecode_error3(rc_); \
    return 1;                \
  }

static iwrc documents_visitor(EJDB_EXEC *ctx, const EJDB_DOC doc, int64_t *step) {
  // Print document to stderr
  return jbl_as_json(doc->raw, jbl_fstream_json_printer, stderr, JBL_PRINT_PRETTY);
}

#undef print_message
#define print_message(fmt, ...)          \
{                                               \
  iwlog_info("Thread[%u] | " fmt, (unsigned int)0, ## __VA_ARGS__); \
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// IWKV_NO_TRIM_ON_CLOSE
// IWKV_TRUNC
iwrc get_ejdb(EJDB *db) {
  EJDB_OPTS opts = {
    .kv       = {
      .path   = "statistic.db",
      .oflags = IWKV_TRUNC,
      .wal = {
        .savepoint_timeout_sec = 5,
        .checkpoint_timeout_sec = 10,
        .wal_buffer_sz = 4096,
        .checkpoint_buffer_sz = 1024 * 1024
      },
    },
    .no_wal = 0,
    .sort_buffer_sz = 1024 * 1024,
    .document_buffer_sz = 16 * 1024
  };
  
  print_message("step-1 ejdb_init");
  iwrc rc = ejdb_init();
  CHECK(rc);

  print_message("step-2 ejdb_open");
  rc = ejdb_open(&opts, db);
  CHECK(rc);
  return 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
iwrc show_db_meta(EJDB db) {
  JBL jbl = 0; // Json document
  iwrc rc = ejdb_get_meta(db, &jbl);
  RCGO(rc, finish);

  fprintf(stderr, "\n");
  rc = jbl_as_json(jbl, jbl_fstream_json_printer, stderr, JBL_PRINT_CODEPOINTS);
  RCGO(rc, finish);
  fprintf(stderr, "\n");
finish:
  if (jbl) {
    jbl_destroy(&jbl);
  }
  return 0;
}


int main15() {

  EJDB_OPTS opts = {
    .kv       = {
      .path   = "example.db",
      .oflags = IWKV_TRUNC
    }
  };
  EJDB db;     // EJDB2 storage handle
  int64_t id;  // Document id placeholder
  JQL q = 0;   // Query instance
  JBL jbl = 0; // Json document

  iwrc rc = ejdb_init();
  CHECK(rc);

  rc = ejdb_open(&opts, &db);
  CHECK(rc);

  // First record
  rc = jbl_from_json(&jbl, "{\"name\":\"Bianca\", \"age\":4}");
  RCGO(rc, finish);
  rc = ejdb_put_new(db, "parrots", jbl, &id);
  RCGO(rc, finish);
  jbl_destroy(&jbl);

  // Second record
  rc = jbl_from_json(&jbl, "{\"name\":\"Darko\", \"age\":8}");
  RCGO(rc, finish);
  rc = ejdb_put_new(db, "parrots", jbl, &id);
  RCGO(rc, finish);
  jbl_destroy(&jbl);

  // Now execute a query
  rc = jql_create(&q, "parrots", "/[age > :age]");
  RCGO(rc, finish);

  EJDB_EXEC ux = {
    .db      = db,
    .q       = q,
    .visitor = documents_visitor
  };

  // Set query placeholder value.
  // Actual query will be /[age > 3]
  rc = jql_set_i64(q, "age", 0, 3);
  RCGO(rc, finish);

  // Now execute the query
  rc = ejdb_exec(&ux);

finish:
  if (q) {
    jql_destroy(&q);
  }
  if (jbl) {
    jbl_destroy(&jbl);
  }
  ejdb_close(&db);
  CHECK(rc);
  return 0;
}


// delete function /////////////////////////////////////////////////////////////////////////////////////////////////////
iwrc delete_record_plus(EJDB db, char *collection, uint64_t from, uint64_t to, int limit) {
  JQL q = 0;
  
  char deleteSql[128];
  memset(deleteSql, 0, sizeof(deleteSql));
  // sprintf(deleteSql, "/[age >= %d ] and /[age <= %d ] | del | limit %d", from, to, limit);
  //sprintf(deleteSql, "/[age <= %d ] | del | limit %d", to, limit);
  //sprintf(deleteSql, "(/[time_ <= %ld ]) | del | limit %d", to, limit);
  //sprintf(deleteSql, "(/[time_ <= %llu ]) | del | asc /time_ limit %d count", to, limit);
  sprintf(deleteSql, "(/[time_ <= %llu ]) | del | limit %d count", to, limit);
  print_message("sql=%s", deleteSql);
  iwrc rc = jql_create(&q, collection, deleteSql);
  RCGO(rc, finish);

  EJDB_EXEC ux = {
    .db      = db,
    .q       = q,
    .log     = 0,
    .visitor = 0
  };

  rc = ejdb_exec(&ux);
  RCGO(rc, finish);
  print_message("delete successful");
finish:
  if (q) {
    jql_destroy(&q);
  }
  return 0;
}

// queryex function /////////////////////////////////////////////////////////////////////////////////////////////////////
iwrc queryex(EJDB db, char *collection, uint64_t value, int limit) {
    IWXSTR *xstr = iwxstr_new();
    EJDB_DOC doc = NULL;
    EJDB_LIST listp;

    char sql[1024];
    memset(sql, 0, sizeof(sql));
    sprintf(sql, "(/[time_ <= %llu]) | limit %d", value, limit);
    //sprintf(sql, "(/[time_ >= 0]) | limit %d", limit);
    print_message("query=%s", sql);

    iwrc rc = ejdb_list2(db, collection, sql, limit, &listp);
    RCGO(rc, finish);
    doc = listp->first;
    while (doc != NULL) {
        iwxstr_clear(xstr);
        rc = jbl_as_json(doc->raw, jbl_xstr_json_printer, xstr, 0);
        print_message("result=%s", iwxstr_ptr(xstr));
        doc = doc->next;
    }
    print_message("query successful");
finish:
    if (xstr) {
        iwxstr_destroy(xstr);
    }
    if (listp) {
        ejdb_list_destroy(&listp);
    }
    return rc;
}

// add record function /////////////////////////////////////////////////////////////////////////////////////////////////
iwrc add_record(EJDB db, char *collection, int total, uint64_t time) {
  JBL jbl = 0; // Json document
  int64_t id;  // Document id placeholder
  char json[1024];
  for (int ii = 0; ii < total; ii++) {
    time++;
    memset(json, 0, sizeof(json));
    sprintf(json, "{\"domain_\":\"SAMGR\",\"name_\":\"SAMGR_GETSA_FREQUENCY\",\"type_\":2,\"time_\":%llu,\"tz_\":\"+0000\",\"pid_\":1800,\"tid_\":1800,\"uid_\":0,\"level_\":\"MINOR\",\"tag_\":\"statistic\",\"id_\":\"14213628899912353898\",\"info_\":\"\"}", time);
    iwrc rc = jbl_from_json(&jbl, json);
    RCGO(rc, finish);

    rc = ejdb_put_new(db, collection, jbl, &id);
    RCGO(rc, finish);
    if (jbl) {
      jbl_destroy(&jbl);
      jbl = 0;
    }
  }

finish:
  if (jbl) {
    jbl_destroy(&jbl);
  }
  return 0;
}

int main(int argc, char* argv[]) {
  EJDB db = 0;
  iwrc rc = get_ejdb(&db);
  CHECK(rc);

  // init db file to 100M
  char *collection = "collection";
  ejdb_ensure_index(db, collection, "/time_", EJDB_IDX_I64);

  uint64_t time = 1666330580689;
  int total = 100000;
  add_record(db, collection, 100000, time);

  for (int ii = 0; ii < 5; ii++) {
    print_message("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
    show_db_meta(db);
    delete_record_plus(db, collection, 100, time + total, 1000);
    show_db_meta(db);
    queryex(db, collection, time, 1);
  }
  ejdb_close(&db);
  return 0;
}